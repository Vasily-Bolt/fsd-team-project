// import * as $ from 'jquery'
import '@/jquery-ui/jquery-ui.js'
import '@/jquery-ui/jquery-ui.css'
import '@/assets/blocks/range-slider/range-slider.js'

import '@/pages/uikit/styles.sass'

// $(()=> {
//   $('#slider-range').text('ЖОПА')
// });
